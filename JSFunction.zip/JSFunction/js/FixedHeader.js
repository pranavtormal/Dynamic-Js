
/***** 
	CellType
	0 : Header Cells Except Fixed column header
	1 : Header cells of fixed column
	2 : Fixed column cells
*******/
function FixedCell(CellObj, CellType){
	var divPos		= CellObj.closest("div.FixHeader").position();
	var tablePos	= CellObj.closest("table.FixHeader").position();
	var IsScroll	= ((tablePos.top<0)||(tablePos.left<0));
	var IsTopScroll		= (tablePos.top<0);
	var IsLeftScroll	= (tablePos.left<0);
	var orgLeft		= CellObj.attr("orgLeft");
	
	CellObj.css("position",IsScroll?"absolute":"");
	CellObj.css("top",IsTopScroll?(0-parseInt(tablePos.top)):IsLeftScroll?1:0);
	CellObj.css("left",parseInt(orgLeft)-1);
}

function RefreshPage(FixCol){
	try{
		var firstRowSel		= ":nth-child("+FixCol+")"
		if (FixCol==0){
			$("div.FixHeader:visible table.FixHeader tr:visible:first>td").each(function(){
				FixedCell($(this), 0);
			});
		}
		else {
			/*$("div.FixHeader:visible table.FixHeader tr:visible:first>td:nth-child("+FixCol+")").nextAll().each(function(){
						FixedCell($(this), 0);
			});*/
			
			/* This is for keep first header row fixed -By Sunil*/
			var i=1;
			$("div.FixHeader:visible table.FixHeader tr:visible:first>td").each(function(){
				if(i>=FixCol){
					FixedCell($(this), 0);
				}
				i=i+1;
			});
			
			
			/*$("div.FixHeader:visible table.FixHeader tr:visible:first>td:nth-child("+FixCol+")").each(function(){
			  FixedCell($(this), 0);
			});*/
		}
			
		/*// Fixed first Row
		$("div.FixHeader:visible table.FixHeader tr:visible:first>td"+firstRowSel).nextAll().each(function(){
			var divPos		= $(this).closest("div.FixHeader").position();
			var tablePos	= $(this).closest("table.FixHeader").position();
			var IsScroll	= ((tablePos.top<0)||(tablePos.left<0));
			var IsTopScroll		= (tablePos.top<0);
			var IsLeftScroll	= (tablePos.left<0);
			var orgLeft		= $(this).attr("orgLeft");
			
			$(this).css("position",IsScroll?"absolute":"");
			$(this).css("top",IsTopScroll?(0-parseInt(tablePos.top)):IsLeftScroll?1:0);
			$(this).css("left",parseInt(orgLeft)-1);
		});
		*/// Fixed first Row
		
		// Fixed first Cell
		$("div.FixHeader:visible table.FixHeader tr:visible:first>td:nth-child("+FixCol+")").each(function(){
			var divPos		= $(this).closest("div.FixHeader").position();
			var tablePos	= $(this).closest("table.FixHeader").position();
			var IsScroll	= ((tablePos.top<0)||(tablePos.left<0));
			var IsTopScroll		= (tablePos.top<0);
			var IsLeftScroll	= (tablePos.left<0);
			var orgLeft		= $(this).attr("orgLeft");
			
			$(this).css("position",IsScroll?"absolute":"");
			$(this).css("top",IsTopScroll?(0-parseInt(tablePos.top)):IsLeftScroll?1:0);
			//$(this).css("left",parseInt(divPos.left)-parseInt(tablePos.left));
			$(this).css("left",(-1-parseInt(tablePos.left)+parseInt(orgLeft)));
		});
		// Fixed first Cell
		
		// Fixed first column
		
		$("div.FixHeader:visible table.FixHeader tr:visible:not(div.FixHeader:visible table.FixHeader tr:visible:first)>td:nth-child("+FixCol+")").each(function(){
			var divPos		= $(this).closest("div.FixHeader").position();			// $("div.FixHeader").position();
			var tablePos	= $(this).closest("table.FixHeader").position();		// $("div.FixHeader:visible table.FixHeader").position();
			var IsScroll	= ((tablePos.top<0)||(tablePos.left<0));
			var orgLeft		= $(this).attr("orgLeft");
			
			$(this).css("position",IsScroll?"absolute":"");
			//$(this).css("left",parseInt(divPos.left)-parseInt(tablePos.left));
			$(this).css("left",(-1-parseInt(tablePos.left)+parseInt(orgLeft)));
			//tempCol=tempCol+1;
		});
		// Fixed first column
	}catch(e){
		writeErrlog(e);
	}
}
// function for set fix values
function SetValues(Obj){
	try{
		Obj.css("height",Obj.height());
		Obj.css("width",Obj.width());
		Obj.attr("orgTop",Obj.position().top);
		if (Obj.attr("orgLeft")==undefined)
			Obj.attr("orgLeft",Obj.position().left);
		Obj.css("background",Obj.closest("tr:visible").prop("background"));
	}catch(e){
		writeErrlog(e);
	}
}

function UpdatePage_OnScroll(FixCol){
	if (!FixCol)
		var FixCol = $("div.FixHeader:visible").attr("FixCol");
	
	if (FixCol==0)
		RefreshPage(0);
	else {
		for (var i=1; i<=FixCol; i++){
			RefreshPage(i);
		}
	}
}

var scrollTimeout = null;
function FixedHeaderColumn(FixCol, UpdAftScrl){
	try{	
		if ($("div.FixHeader:visible").attr("FixCol")==undefined){
			$("div.FixHeader:visible").attr("FixCol", FixCol);
			$("div.FixHeader:visible").css("position", "absolute");
			
			// Set table fix values
			$("div.FixHeader:visible table.FixHeader").each(function(){
				SetValues($(this));
			});
			// Set all tr fix values
			$("div.FixHeader:visible table.FixHeader tr").each(function(){
				SetValues($(this));
			});
			$("div.FixHeader:visible table.FixHeader tr:visible:first").addClass("tablegrey");
			
			// Set first row of data fix values
			$("div.FixHeader:visible table.FixHeader tr:visible:nth-child(1) td").each(function(){
				SetValues($(this));
			});
			
			// Set header row fix values
			$("div.FixHeader:visible table.FixHeader tr:visible:first>td").each(function(){
				$(this).addClass("tablegrey");
				SetValues($(this));
			});
			
			if (FixCol==0)
				RefreshPage(0);
			else {
				for (var i=1; i<=FixCol; i++){
					$("div.FixHeader:visible table.FixHeader tr:visible:first>td:nth-child("+i+")").each(function(){
						$(this).css("z-index",5);
					});
					$("div.FixHeader:visible table.FixHeader tr:visible td:nth-child("+i+")").each(function(){
						SetValues($(this));
					});
					
					setTimeout("RefreshPage("+i+");",100);
				}
			}
		}
		if (UpdAftScrl) {
			$("div.FixHeader:visible").scroll(function(){
					if (scrollTimeout) clearTimeout(scrollTimeout);
					scrollTimeout = setTimeout(function(){
						UpdatePage_OnScroll();
					},50);
			});
		}
		else {
			$("div.FixHeader:visible").scroll(function(){
				UpdatePage_OnScroll();
			});
		}
	} catch(e) {
		writeErrlog(e);
	}
}

